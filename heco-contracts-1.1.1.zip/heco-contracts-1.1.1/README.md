# huobi-eco-contracts

## Prepare

Install dependency:

```bash
yarn
```

Compile files:

```bash
yarn compile
```

Release solidity files will be generated in `cache` folder.

## unit test
Test:

```bash
yarn test
```
